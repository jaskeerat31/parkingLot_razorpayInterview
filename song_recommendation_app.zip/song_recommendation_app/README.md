# Song Recommendation

To get started, clone this repo and run the following to install the required packages:

``pip install -r requirements.txt``

To run the app, you can run:

``streamlit run app.py``
