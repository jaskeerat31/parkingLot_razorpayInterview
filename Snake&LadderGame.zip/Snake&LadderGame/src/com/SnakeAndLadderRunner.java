package com;

import com.snakeandladder.models.Ladder;
import com.snakeandladder.models.Player;
import com.snakeandladder.models.Snake;
import com.snakeandladder.services.SnakeAndLadderService;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// Runner class
public class SnakeAndLadderRunner {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        // 1. Create Snakes based on user input .. Snake start position is greater than snake end position
        int noOfSnakes = scanner.nextInt();
        List<Snake> snakes = new ArrayList<>();
        for (int i = 0; i < noOfSnakes; i++) {
            snakes.add(new Snake(scanner.nextInt(), scanner.nextInt()));
        }

        // 2. Create Ladders based on user input .. Ladder start position is less than ladder end position
        int noOfLadders = scanner.nextInt();
        List<Ladder> ladders = new ArrayList<>();
        for (int i = 0; i < noOfLadders; i++) {
            ladders.add(new Ladder(scanner.nextInt(), scanner.nextInt()));
        }

        // 3. Create number of players .. include player name and Unique Id
        int noOfPlayers = scanner.nextInt();
        List<Player> players = new ArrayList<>();
        for (int i = 0; i < noOfPlayers; i++) {
            players.add(new Player(scanner.next()));
        }

        // 4. Passing everything to Orchestrator Service
        SnakeAndLadderService snakeAndLadderService = new SnakeAndLadderService();

        snakeAndLadderService.setPlayers(players);
        snakeAndLadderService.setSnakes(snakes);
        snakeAndLadderService.setLadders(ladders);

        // 5. Let the game begins
        snakeAndLadderService.startGame();
    }

}