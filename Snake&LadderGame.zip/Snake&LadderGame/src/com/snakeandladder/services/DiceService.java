package com.snakeandladder.services;

import java.util.Random;

public class DiceService {

    //The game will have a six sided dice numbered from 1 to 6 and will always give a random number on rolling it.
    public static int roll() {
        return new Random().nextInt(6) + 1;
    }
}
