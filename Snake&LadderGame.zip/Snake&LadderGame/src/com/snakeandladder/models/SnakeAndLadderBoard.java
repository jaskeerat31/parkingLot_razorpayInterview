package com.snakeandladder.models;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SnakeAndLadderBoard {
    private int size;
    private List<Snake> snakes;
    private List<Ladder> ladders;

    // Player UUID, current Position
    private Map<String, Integer> playerPosition;

    public SnakeAndLadderBoard(int size) {
        this.size = size;
        this.snakes = new ArrayList<>();
        this.ladders = new ArrayList<>();
        this.playerPosition = new HashMap<>();
    }

    public Map<String, Integer> getPlayerPosition() {
        return playerPosition;
    }

    public List<Snake> getSnakes() {
        return snakes;
    }

    public List<Ladder> getLadders() {
        return ladders;
    }

    public void setPlayerPosition(Map<String, Integer> mp){
        this.playerPosition = mp;
    }

    public void setSnakes(List<Snake> snakesList) {
        this.snakes = snakesList;
    }

    public void setLadders(List<Ladder> laddersList) {
        this.ladders = laddersList;
    }

    public int getSize() {
        return size;
    }
}
