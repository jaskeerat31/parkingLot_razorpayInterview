package com.snakeandladder.models;

public class Snake {
    private int start;
    private int end;

    public Snake(int i, int j) {
        this.start = i;
        this.end = j;
    }

    public int getStart() {
        return start;
    }

    public int getEnd() {
        return end;
    }
}
