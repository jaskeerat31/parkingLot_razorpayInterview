package com.parkinglot.service;
import com.parkinglot.models.Ticket;
import com.parkinglot.models.Vehicle;
import com.parkinglot.exceptions.*;
import com.parkinglot.strategy.ParkingChargeStrategy;

public interface Parking {
	public Ticket park(Vehicle vehicle) throws ParkingFullException;
	public int unPark(Ticket ticket, ParkingChargeStrategy parkingCostStrategy) throws InvalidVehicleNumberException;

}
