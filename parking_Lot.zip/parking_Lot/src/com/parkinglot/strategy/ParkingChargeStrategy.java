package com.parkinglot.strategy;

public interface ParkingChargeStrategy {
	int getCharge(int parkHours);
}
