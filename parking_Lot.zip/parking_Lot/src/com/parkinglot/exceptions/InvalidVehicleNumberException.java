package com.parkinglot.exceptions;

public class InvalidVehicleNumberException extends Exception {
	public InvalidVehicleNumberException(String s) {
		super(s);
	}
}
