package com.parkinglot.enums;

public enum VehicleSize{
	TWOWHEELER,  FOURWHEELER;
}
