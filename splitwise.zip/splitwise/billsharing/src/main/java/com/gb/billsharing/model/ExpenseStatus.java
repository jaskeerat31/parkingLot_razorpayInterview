package com.gb.billsharing.model;

public enum ExpenseStatus {
    CREATED,
    PENDING,
    SETTLED
}
