package com.parkinglot;

import java.util.*;
//import java.util.ArrayList;

import com.parkinglot.enums.VehicleType;
import com.parkinglot.models.ParkingSlot;
import com.parkinglot.models.Vehicle;
import com.parkinglot.models.Ticket;

//main class
public class ParkingLot {
    Map<ParkingSlot, Vehicle> mp;
    List<ParkingSlot> parkingslots;
    int suvcarCount;
    int hatchbackCount;
    private String adminName;
    boolean hasSpace;

    public ParkingLot() {
        this.suvcarCount = 0;
        this.hatchbackCount = 0;
        this.mp = new HashMap<>();
    }

    public int getSUVCount() {
        return suvcarCount;
    }

    public int gethatchbackCount() {
        return hatchbackCount;
    }

    public void setSUVcount() {
        this.suvcarCount += 1;
    }

    public void sethatchbackcount() {
        this.hatchbackCount += 1;
    }

    public void parkCar(Vehicle vh) {
        if(this.isSpaceAvailable(vh.type)){
            ParkingSlot p = new ParkingSlot(vh, vh.type);
            mp.put(p, vh);
            vh.ticket = new Ticket(vh.vehicleNumber, 1);
            }
        if (vh.type == VehicleType.SUV) {
            setSUVcount();
        } else sethatchbackcount();
    }

    public int checkoutCarAndGetAmount(Vehicle vh, int checkedoutHour) {
        vh.ticket.calculateAmount(checkedoutHour, vh.type);
        mp.remove(vh.slotParked);
        return vh.ticket.amount;
    }

    public boolean isSpaceAvailable(VehicleType vehicleType) {
        if(vehicleType == VehicleType.SUV) {
            return suvcarCount <= 50;
        } else {
            return (hatchbackCount <= 50) || (hatchbackCount == 50 && suvcarCount <= 50);
        }
    }
}
