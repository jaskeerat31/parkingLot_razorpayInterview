package com.parkinglot.models;
import com.parkinglot.enums.VehicleType;
import com.parkinglot.services.ParkingLotService;

public class Ticket {
    public int ticketID;
    public int amount;
    public int vehicleNumber;
    public int checkedInHour;

    public Ticket(int vnumber, int checkedInHour) {
        this.vehicleNumber = vnumber;
        this.amount = 0;
        this.checkedInHour = checkedInHour;
    }

    public void calculateAmount(int checkedoutHour, VehicleType vtype) {
        int hours = checkedoutHour = this.checkedInHour;
            if (vtype == VehicleType.SUV) {
                this.amount =  hours * 20;
            } else {
                this.amount = hours * 10;
            }
        }
}
