package com.parkinglot.models;
import com.parkinglot.enums.VehicleType;

public class Vehicle {
    public VehicleType type;
    public int vehicleNumber;
    public Ticket ticket;
    public ParkingSlot slotParked;

    public Vehicle(VehicleType vtype, int vno) {
        this.type = vtype;
        this.vehicleNumber = vno;
    }
}
