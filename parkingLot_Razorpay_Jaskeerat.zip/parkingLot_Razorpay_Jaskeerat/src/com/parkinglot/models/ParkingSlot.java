package com.parkinglot.models;
import com.parkinglot.enums.VehicleType;
import java.util.UUID;
public class ParkingSlot {
    int slotID;
    // Vehicle vehicle;
    boolean isAvailable;
    VehicleType vtype;

    public ParkingSlot(Vehicle vh, VehicleType vtype) {
        //this.vehicle = vh;
        this.vtype = vtype;
        this.isAvailable = true;
    }

    // public Vehicle getVehicle() {
    //     return vehicle;
    // }
    
    public boolean isSlotAvailable() {
        return this.isAvailable;
    } 
    
    public int getSlot() {
        return this.slotID;
    }
}
