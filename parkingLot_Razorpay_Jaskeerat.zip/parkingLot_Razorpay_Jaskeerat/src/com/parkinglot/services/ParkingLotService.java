package com.parkinglot.services;

import com.parkinglot.ParkingLot;
import com.parkinglot.enums.VehicleType;

public class ParkingLotService {
    ParkingLot parkinglot;

    public void trackCarCount(VehicleType vtype) {
        if (vtype == VehicleType.SUV) {
            parkinglot.setSUVcount();
        } else parkinglot.sethatchbackcount();
    }
}
