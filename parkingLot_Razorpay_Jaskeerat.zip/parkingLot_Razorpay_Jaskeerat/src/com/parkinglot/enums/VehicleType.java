package com.parkinglot.enums;

public enum VehicleType {
    SUV,
    HATCHBACK
}
