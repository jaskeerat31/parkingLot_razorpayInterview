import com.parkinglot.ParkingLot;
import com.parkinglot.models.*;
import com.parkinglot.enums.VehicleType;
public class App {
    public static void main(String[] args) throws Exception {
        ParkingLot pl = new ParkingLot();
        Vehicle vh = new Vehicle(VehicleType.SUV, 123);
        pl.parkCar(vh);
        pl.checkoutCarAndGetAmount(vh, 2);
        System.out.println(vh.ticket.amount);
    }
}
