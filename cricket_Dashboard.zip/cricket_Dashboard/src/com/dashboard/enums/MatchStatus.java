package com.dashboard.enums;

public enum MatchStatus {
    NOT_STARTED,
    IN_PROGRESS,
    COMPLETED
}
