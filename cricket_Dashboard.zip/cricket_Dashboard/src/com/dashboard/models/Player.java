package com.dashboard.models;

abstract public class Player {
    String playername;
    int age;

    public Player(String name) {
        this.playername = name;
    }

    public String getPlayerName() {
        return playername;
    }
}
