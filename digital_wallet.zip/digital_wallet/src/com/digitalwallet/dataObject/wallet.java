package com.digitalwallet.dataObject;
import java.util.HashMap;
import java.util.Map;
import com.digitalwallet.entity.Account;

public class wallet {
    private Map<Integer, Account> accountMap;
    
    public wallet() {
        this.accountMap = new HashMap<>();;
    }
    public Map<Integer, Account> getAccountMap() {
        return accountMap;
    }
    public void setAccountMap(Map<Integer, Account> accountMap) {
        this.accountMap = accountMap;
    }
}
